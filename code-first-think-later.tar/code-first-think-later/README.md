# code-first-think-later

## Unpacking
```bash
$ tar -xvf code-first-think-later.tar
```

## Building and Running
- Open up Qt Creator
- File > Open File or Project...
- Open code-first-think-later/src/cupid.pro
- Build > Build Project "cupid"
- Build > Run

## Operating Instructions
- To log in, enter the User's ID number.
- The 25 Student accounts have IDs in the range 1 to 25, inclusive.
- The 2 Administrator accounts have IDs in the range 26 - 27, inclusive.
