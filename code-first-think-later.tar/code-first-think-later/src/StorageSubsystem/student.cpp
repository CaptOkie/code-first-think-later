#include "student.h"

Student::Student()
{ }

Student::~Student()
{ }
