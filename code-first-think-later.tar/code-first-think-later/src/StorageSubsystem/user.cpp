#include "user.h"

User::User()
{ }

User::~User()
{ }
