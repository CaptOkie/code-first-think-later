#include "admin.h"

Admin::Admin()
{ }

Admin::~Admin()
{ }
