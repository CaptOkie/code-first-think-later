#include "question.h"

Question::Question()
{ }

Question::~Question()
{ }
