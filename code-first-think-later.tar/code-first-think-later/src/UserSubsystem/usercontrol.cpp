#include "usercontrol.h"

UserControl::UserControl()
{
}

UserControl::~UserControl()
{
}
