#include "matcher.h"

Matcher::Matcher()
{ }

Matcher::~Matcher()
{ }
